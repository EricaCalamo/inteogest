// Placeholder for Next.js entry point
export { default } from '../INteoGestMockup';
