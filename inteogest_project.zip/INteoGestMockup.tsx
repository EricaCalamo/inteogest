import { useState } from "react";
import Image from "next/image";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CalendarDays, FileText, Users, ShieldCheck, BarChart2, Bell, UploadCloud } from "lucide-react";

export default function INteoGestMockup() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [activeSection, setActiveSection] = useState("dashboard");

  const sections = {
    dashboard: "Dashboard",
    clienti: "Clienti",
    polizze: "Polizze",
    sinistri: "Sinistri",
    report: "Report",
    notifiche: "Notifiche",
    documenti: "Documenti"
  };

  if (!loggedIn) {
    return (
      <div className="flex items-center justify-center h-screen bg-blue-50">
        <Card className="w-full max-w-md p-6">
          <CardContent className="space-y-4">
            <div className="text-center mb-4">
              <Image src="/logo-inteo.png" alt="INteo.gest logo" width={160} height={40} className="mx-auto" />
              <h2 className="text-xl font-semibold mt-2 text-blue-800">Accesso INteo.gest</h2>
            </div>
            <Input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <Input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <Button className="w-full" onClick={() => setLoggedIn(true)}>Accedi</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex h-screen w-full">
      <div className="w-64 bg-blue-900 text-white p-4 space-y-4">
        <div className="mb-6">
          <Image 
            src="/logo-inteo.png" 
            alt="INteo.gest logo"
            width={160} 
            height={40} 
            className="mx-auto"
          />
        </div>
        {Object.entries(sections).map(([key, label]) => (
          <Button
            key={key}
            variant="ghost"
            className={`w-full justify-start ${activeSection === key ? "bg-blue-700" : ""}`}
            onClick={() => setActiveSection(key)}
          >
            {key === "dashboard" && <CalendarDays className="mr-2 w-4" />}
            {key === "clienti" && <Users className="mr-2 w-4" />}
            {key === "polizze" && <FileText className="mr-2 w-4" />}
            {key === "sinistri" && <ShieldCheck className="mr-2 w-4" />}
            {key === "report" && <BarChart2 className="mr-2 w-4" />}
            {key === "notifiche" && <Bell className="mr-2 w-4" />}
            {key === "documenti" && <UploadCloud className="mr-2 w-4" />}
            {label}
          </Button>
        ))}
      </div>

      <div className="flex-1 bg-gray-100 p-6 overflow-auto">
        <h2 className="text-xl font-semibold mb-4">{sections[activeSection]}</h2>
        {/* ...resto del codice omesso per brevità... */}
      </div>
    </div>
  );
}
